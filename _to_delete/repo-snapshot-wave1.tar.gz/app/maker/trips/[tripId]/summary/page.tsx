import Link from "next/link";
import type { CSSProperties } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  Home,
  Lightbulb,
  Palette,
  ShieldCheck,
  Sparkles,
  TrainFront,
  Trash2,
} from "lucide-react";
import { MakerProgress } from "@/components/maker-progress";
import { getAppliedTripRecords } from "@/lib/applied-trip-records";
import {
  createGeneratedTripSummaryView,
  type GeneratedTripSummaryCityNote,
  type GeneratedTripSummaryDay,
  type GeneratedTripSummaryDayEntry,
  type GeneratedTripSummaryWarning,
} from "@/lib/generated-trip-summary";
import type { StructuredReviewEditField } from "@/lib/generated-trip-review";
import { getTripStyleSettings } from "@/lib/style-settings";
import { getThemeDirection } from "@/lib/style-settings-config";
import { getMakerTrip } from "@/lib/trips";

const ENTRY_ICONS = {
  activity: Sparkles,
  review: AlertCircle,
  stay: Home,
  transport: TrainFront,
} satisfies Record<GeneratedTripSummaryDayEntry["kind"], typeof Sparkles>;

const ENTRY_LABELS = {
  activity: "Activity",
  review: "Needs review",
  stay: "Stay",
  transport: "Travel",
} satisfies Record<GeneratedTripSummaryDayEntry["kind"], string>;

function createDayCardStyle({
  accentColor,
  softColor,
}: {
  accentColor: string | null;
  softColor: string | null;
}): CSSProperties {
  return {
    background:
      softColor && accentColor
        ? `linear-gradient(180deg, ${softColor} 0%, #ffffff 44%)`
        : undefined,
    borderColor: accentColor ? `${accentColor}55` : undefined,
  };
}

function EditFieldInput({ field }: { field: StructuredReviewEditField }) {
  const baseClass =
    "mt-1 w-full rounded-md border border-ink/10 bg-white px-3 py-2 text-sm text-ink outline-none transition focus:border-moss/40";

  if (field.type === "textarea") {
    return (
      <textarea
        className={`${baseClass} min-h-24`}
        defaultValue={field.value}
        name={`field:${field.name}`}
      />
    );
  }

  if (field.type === "select") {
    return (
      <select className={baseClass} defaultValue={field.value} name={`field:${field.name}`}>
        <option value="">Not set</option>
        {field.options?.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    );
  }

  return (
    <input
      className={baseClass}
      defaultValue={field.value}
      name={`field:${field.name}`}
      type={field.type}
    />
  );
}

function SummaryEntryActions({
  entry,
  tripId,
}: {
  entry: GeneratedTripSummaryDayEntry;
  tripId: string;
}) {
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {entry.editFields.length > 0 ? (
        <details className="w-full rounded-md border border-ink/10 bg-white p-3">
          <summary className="cursor-pointer text-xs font-semibold text-ink/60">
            Edit
          </summary>
          <form
            action={`/maker/trips/${tripId}/data/decisions`}
            className="mt-3 grid gap-3 md:grid-cols-2"
            method="post"
          >
            <input name="action" type="hidden" value="edit" />
            <input name="returnTo" type="hidden" value="summary" />
            <input name="subjectId" type="hidden" value={entry.subjectId} />
            <input name="subjectType" type="hidden" value={entry.subjectType} />
            {entry.editFields.map((field) => (
              <label
                className={field.type === "textarea" ? "md:col-span-2" : ""}
                key={field.name}
              >
                <span className="text-xs font-semibold text-ink/55">
                  {field.label}
                </span>
                <EditFieldInput field={field} />
              </label>
            ))}
            <div className="md:col-span-2">
              <button
                className="inline-flex rounded-md bg-ink px-3 py-2 text-xs font-semibold text-paper"
                type="submit"
              >
                Save edit
              </button>
            </div>
          </form>
        </details>
      ) : null}

      {entry.canMoveToCityTip ? (
        <form action={`/maker/trips/${tripId}/data/decisions`} method="post">
          <input name="action" type="hidden" value="move_to_city_tip" />
          <input name="returnTo" type="hidden" value="summary" />
          <input name="subjectId" type="hidden" value={entry.subjectId} />
          <input name="subjectType" type="hidden" value={entry.subjectType} />
          <input name="targetLegId" type="hidden" value={entry.targetLegId ?? ""} />
          <button
            className="inline-flex items-center gap-2 rounded-md border border-ink/10 bg-white px-3 py-2 text-xs font-semibold text-ink/70"
            type="submit"
          >
            <Lightbulb size={14} />
            Move to city tips
          </button>
        </form>
      ) : null}

      <form action={`/maker/trips/${tripId}/data/decisions`} method="post">
        <input name="action" type="hidden" value="delete" />
        <input name="returnTo" type="hidden" value="summary" />
        <input name="subjectId" type="hidden" value={entry.subjectId} />
        <input name="subjectType" type="hidden" value={entry.subjectType} />
        <button
          className="inline-flex items-center gap-2 rounded-md border border-clay/20 bg-clay/10 px-3 py-2 text-xs font-semibold text-clay"
          type="submit"
        >
          <Trash2 size={14} />
          Remove
        </button>
      </form>
    </div>
  );
}

function SummaryEntry({
  entry,
  tripId,
}: {
  entry: GeneratedTripSummaryDayEntry;
  tripId: string;
}) {
  const Icon = ENTRY_ICONS[entry.kind];
  const detailLabel =
    entry.kind === "activity" || entry.kind === "review"
      ? "Description"
      : "Details";

  return (
    <div className="grid gap-2 px-4 py-3 md:grid-cols-[128px_1fr]">
      <div className="flex items-start gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-ink/45">
        <Icon className="mt-0.5 shrink-0" size={15} />
        {ENTRY_LABELS[entry.kind]}
      </div>
      <div className="min-w-0">
        <div className="flex flex-col gap-1 md:flex-row md:items-start md:justify-between">
          <p className="text-sm font-semibold text-ink">{entry.title}</p>
          {entry.meta ? (
            <p className="shrink-0 text-xs font-semibold text-ink/45">
              {entry.meta}
            </p>
          ) : null}
        </div>
        {entry.detail ? (
          <details className="mt-2">
            <summary className="cursor-pointer list-none text-xs font-semibold text-moss">
              {detailLabel}
            </summary>
            <p className="mt-1 text-sm leading-6 text-ink/60">{entry.detail}</p>
          </details>
        ) : null}
        <SummaryEntryActions entry={entry} tripId={tripId} />
      </div>
    </div>
  );
}

function SummaryDayCard({
  day,
  style,
  tripId,
}: {
  day: GeneratedTripSummaryDay;
  style: CSSProperties;
  tripId: string;
}) {
  const stayEntries = day.entries.filter((entry) => entry.kind === "stay");
  const travelEntries = day.entries.filter((entry) => entry.kind === "transport");
  const activityEntries = day.entries.filter(
    (entry) => entry.kind === "activity" || entry.kind === "review"
  );

  return (
    <details
      className="group rounded-md border border-ink/10 bg-white shadow-[0_10px_34px_rgba(29,34,28,0.06)]"
      open
      style={style}
    >
      <summary className="flex cursor-pointer list-none items-start justify-between gap-4 border-b border-ink/10 px-4 py-4">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-moss">
            {day.label}
          </p>
          <h3 className="mt-1 text-lg font-semibold text-ink">{day.title}</h3>
          {day.needsReview ? (
            <p className="mt-2 inline-flex items-center gap-2 rounded-md bg-clay/10 px-2 py-1 text-xs font-semibold text-clay">
              <AlertCircle size={14} />
              Has something to confirm
            </p>
          ) : null}
        </div>
        <ChevronDown
          className="mt-1 shrink-0 text-ink/45 transition group-open:rotate-180"
          size={18}
        />
      </summary>

      <div className="divide-y divide-ink/10">
        {stayEntries.length > 0 ? (
          <div>
            {stayEntries.map((entry) => (
              <SummaryEntry entry={entry} key={entry.id} tripId={tripId} />
            ))}
          </div>
        ) : null}
        {travelEntries.length > 0 ? (
          <div>
            {travelEntries.map((entry) => (
              <SummaryEntry entry={entry} key={entry.id} tripId={tripId} />
            ))}
          </div>
        ) : null}
        {activityEntries.length > 0 ? (
          <div>
            {activityEntries.map((entry) => (
              <SummaryEntry entry={entry} key={entry.id} tripId={tripId} />
            ))}
          </div>
        ) : null}
      </div>
    </details>
  );
}

function DesignPreviewStrip({
  colors,
  themeName,
}: {
  colors: string[];
  themeName: string;
}) {
  return (
    <div className="rounded-md bg-paper px-4 py-3">
      <div className="flex items-center gap-2 text-sm font-semibold text-ink">
        <Palette size={16} />
        {themeName}
      </div>
      <div className="mt-3 flex gap-2">
        {colors.map((color) => (
          <span
            aria-hidden="true"
            className="h-5 w-5 rounded-full border border-ink/10"
            key={color}
            style={{ backgroundColor: color }}
          />
        ))}
      </div>
    </div>
  );
}

function DayByDaySummary({
  days,
  style,
  tripId,
}: {
  days: GeneratedTripSummaryDay[];
  style: CSSProperties;
  tripId: string;
}) {
  return (
    <section className="mt-8">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-moss">
            Day-by-day app shape
          </p>
          <h2 className="mt-1 text-2xl font-semibold text-ink">
            Here&apos;s what we&apos;ve got for you
          </h2>
        </div>
        <p className="max-w-xl text-sm leading-6 text-ink/60">
          Check each day the way travelers read an itinerary: where you are,
          where you&apos;re staying, how you move, and what you&apos;ll do.
        </p>
      </div>

      {days.length > 0 ? (
        <div className="mt-5 space-y-4">
          {days.map((day) => (
            <SummaryDayCard
              day={day}
              key={day.id}
              style={style}
              tripId={tripId}
            />
          ))}
        </div>
      ) : (
        <div className="mt-5 rounded-md bg-white p-4 text-sm text-ink/60">
          No day-by-day records are ready yet.
        </div>
      )}
    </section>
  );
}

function SummaryWarnings({
  tripId,
  warnings,
}: {
  tripId: string;
  warnings: GeneratedTripSummaryWarning[];
}) {
  if (warnings.length === 0) {
    return null;
  }

  const warningGroups = [
    {
      detail: "Structural issues that may materially change the traveler app.",
      severity: "hard" as const,
      title: "Important to review",
    },
    {
      detail: "Useful shape checks that should not block publishing by themselves.",
      severity: "quiet" as const,
      title: "Worth reviewing",
    },
  ]
    .map((group) => ({
      ...group,
      warnings: warnings.filter((warning) => warning.severity === group.severity),
    }))
    .filter((group) => group.warnings.length > 0);

  return (
    <section className="mt-8 rounded-md border border-clay/20 bg-white p-5">
      <div className="flex items-start gap-3">
        <AlertCircle className="mt-0.5 shrink-0 text-clay" size={18} />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-ink">Summary checks</p>
          <div className="mt-3 grid gap-4">
            {warningGroups.map((group) => (
              <div className="grid gap-3" key={group.severity}>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-ink/45">
                    {group.title}
                  </p>
                  <p className="mt-1 text-xs text-ink/50">{group.detail}</p>
                </div>
                {group.warnings.map((warning) => (
                  <div className="rounded-md bg-paper p-4" key={warning.id}>
                    <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-ink">
                          {warning.title}
                        </p>
                        <p className="mt-1 text-sm leading-6 text-ink/60">
                          {warning.detail}
                        </p>
                      </div>
                      <form
                        action={`/maker/trips/${tripId}/data/decisions`}
                        method="post"
                      >
                        <input name="action" type="hidden" value="confirm" />
                        <input name="returnTo" type="hidden" value="summary" />
                        <input name="subjectId" type="hidden" value={warning.subjectId} />
                        <input name="subjectType" type="hidden" value={warning.subjectType} />
                        <button
                          className="inline-flex shrink-0 items-center gap-2 rounded-md border border-ink/10 bg-white px-3 py-2 text-xs font-semibold text-ink/70"
                          type="submit"
                        >
                          <CheckCircle2 size={14} />
                          Mark checked
                        </button>
                      </form>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function CityNotesSummary({
  cityNotes,
}: {
  cityNotes: GeneratedTripSummaryCityNote[];
}) {
  if (cityNotes.length === 0) {
    return null;
  }

  return (
    <section className="mt-8">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-moss">
            City notes
          </p>
          <h2 className="mt-1 text-2xl font-semibold text-ink">
            Ideas and local notes
          </h2>
        </div>
        <p className="text-sm text-ink/55">
          {cityNotes.length === 1
            ? "1 city note"
            : `${cityNotes.length} city notes`}
        </p>
      </div>
      <div className="mt-5 grid gap-3">
        {cityNotes.map((note) => (
          <details
            className="group rounded-md border border-ink/10 bg-white p-4"
            key={note.id}
          >
            <summary className="flex cursor-pointer list-none items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="text-sm font-semibold text-ink">{note.title}</p>
                <p className="mt-1 text-xs font-semibold text-ink/45">
                  {note.meta}
                </p>
              </div>
              <ChevronDown
                className="mt-0.5 shrink-0 text-ink/45 transition group-open:rotate-180"
                size={18}
              />
            </summary>
            {note.detail ? (
              <p className="mt-3 whitespace-pre-line text-sm leading-6 text-ink/60">
                {note.detail}
              </p>
            ) : (
              <p className="mt-3 text-sm text-ink/50">No note details yet.</p>
            )}
          </details>
        ))}
      </div>
    </section>
  );
}

function QuietSummarySection({
  privateDetailCount,
  reviewCount,
}: {
  privateDetailCount: number;
  reviewCount: number;
}) {
  return (
    <section className="mt-6 grid gap-3 md:grid-cols-2">
      <div className="rounded-md border border-ink/10 bg-white p-4">
        <div className="flex gap-3">
          <ShieldCheck className="mt-0.5 shrink-0 text-moss" size={18} />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink">
              Sensitive details protected
            </p>
            <p className="mt-1 text-sm leading-6 text-ink/60">
              {privateDetailCount === 1
                ? "1 detail will stay behind traveler mode."
                : `${privateDetailCount} details will stay behind traveler mode.`}
            </p>
          </div>
        </div>
      </div>
      <div className="rounded-md border border-ink/10 bg-white p-4">
        <div className="flex gap-3">
          <CheckCircle2 className="mt-0.5 shrink-0 text-moss" size={18} />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink">
              Short review queue stays separate
            </p>
            <p className="mt-1 text-sm leading-6 text-ink/60">
              {reviewCount === 0
                ? "No unresolved review decisions remain."
                : `${reviewCount} ${
                    reviewCount === 1 ? "decision" : "decisions"
                  } remain open for you to review.`}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default async function TripSummaryPage({
  params,
}: {
  params: Promise<{ tripId: string }>;
}) {
  const { tripId } = await params;
  const trip = await getMakerTrip(tripId);
  const { latestDraft, records } = await getAppliedTripRecords({
    fallbackTripName: trip.name,
    isDemo: trip.isDemo,
    tripId,
  });
  const summary = records ? createGeneratedTripSummaryView(records) : null;
  const style = await getTripStyleSettings({
    fallbackAppName: summary?.title ?? trip.name,
    tripId,
  });
  const theme = getThemeDirection(style.themeDirection);
  const colors = [
    style.primaryColor,
    style.secondaryColor,
    style.accentColor,
    style.softColor,
  ].filter((color): color is string => Boolean(color));
  const dayCardStyle = createDayCardStyle({
    accentColor: style.accentColor,
    softColor: style.softColor,
  });

  return (
    <main className="min-h-screen bg-paper px-6 py-8 md:px-10">
      <div className="mx-auto max-w-5xl">
        <header className="border-b border-ink/10 pb-6">
          <h1 className="text-4xl font-semibold text-ink">
            Does this look right?
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-6 text-ink/65">
            This is the final shape check before Roamwoven publishes the
            traveler app.
          </p>
        </header>

        <MakerProgress
          completedSteps={5}
          currentStep={6}
          detail="Confirm the trip spine and final app shape before publishing. Later documents should update this spine, not restart it."
          maxAccessibleStep={6}
          tripId={tripId}
        />

        <section className="mt-8 rounded-md border border-ink/10 bg-white p-5">
          <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
              <p className="text-sm font-semibold text-moss">
                {summary?.dateRange ?? "Dates to confirm"}
              </p>
              <h2 className="mt-2 text-2xl font-semibold text-ink">
                {style.appName || summary?.title || trip.name}
              </h2>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-ink/60">
                {summary?.destination ?? "Destinations to confirm"}
              </p>
            </div>
            <div
              className={
                summary?.isSemanticallyClean
                  ? "rounded-md bg-moss/10 px-4 py-3 text-sm font-semibold text-moss"
                  : "rounded-md bg-tide/10 px-4 py-3 text-sm font-semibold text-tide"
              }
            >
              {summary?.isSemanticallyClean
                ? "Ready for final review"
                : "Review suggested"}
            </div>
          </div>

          <div className="mt-6 grid gap-3 md:grid-cols-6">
            {[
              // Dated days only — "Needs placement" is a review bucket, not
              // a trip day (7.17.2 showed "15 Days" for a 14-day trip).
              [
                "Days",
                summary?.days.filter((day) => day.date !== "needs-placement")
                  .length ?? 0,
              ],
              ["Legs", summary?.counts.places ?? 0],
              ["Transport", summary?.counts.transport ?? 0],
              ["Stays", summary?.counts.stays ?? 0],
              ["Plans", summary?.counts.plans ?? 0],
              ["Review", summary?.counts.review ?? 0],
            ].map(([label, count]) => (
              <div key={label} className="rounded-md bg-paper p-4">
                <p className="text-2xl font-semibold text-ink">{count}</p>
                <p className="mt-1 text-sm text-ink/60">{label}</p>
              </div>
            ))}
          </div>

          <div className="mt-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="flex gap-3 rounded-md bg-paper p-4">
              <CalendarDays className="mt-0.5 shrink-0 text-moss" size={18} />
              <p className="text-sm leading-6 text-ink/65">
                If a day, stay, transfer, or activity feels wrong here, go back
                to the review queue. You can also continue with the current
                draft.
              </p>
            </div>
            <DesignPreviewStrip colors={colors} themeName={theme.name} />
          </div>
        </section>

        {summary ? (
          <>
            <SummaryWarnings tripId={tripId} warnings={summary.warnings} />
            <CityNotesSummary cityNotes={summary.cityNotes} />
            <DayByDaySummary
              days={summary.days}
              style={dayCardStyle}
              tripId={tripId}
            />
            <QuietSummarySection
              privateDetailCount={summary.counts.privateDetails}
              reviewCount={summary.counts.review}
            />
          </>
        ) : null}

        {!trip.isDemo && !latestDraft ? (
          <p className="mt-5 rounded-md bg-clay/10 px-3 py-2 text-sm font-semibold text-clay">
            No parsed draft is saved yet. Go back and build the parsed draft
            before using this summary as a final gate.
          </p>
        ) : null}

        <section className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-between">
          <Link
            href={`/maker/trips/${tripId}/data`}
            className="inline-flex items-center gap-2 rounded-md border border-ink/10 bg-white px-4 py-3 text-sm font-semibold text-ink"
          >
            <ArrowLeft size={16} />
            Back to review queue
          </Link>
          {summary ? (
            <Link
              href={`/maker/trips/${tripId}/publish`}
              className="inline-flex items-center gap-2 rounded-md bg-ink px-4 py-3 text-sm font-semibold text-paper"
            >
              Continue to publish
              <ArrowRight size={16} />
            </Link>
          ) : (
            <span className="inline-flex items-center gap-2 rounded-md bg-ink/20 px-4 py-3 text-sm font-semibold text-ink/45">
              Build trip first
              <ArrowRight size={16} />
            </span>
          )}
        </section>
      </div>
    </main>
  );
}
