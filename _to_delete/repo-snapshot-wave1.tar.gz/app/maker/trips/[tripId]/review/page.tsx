import { MakerProgress } from "@/components/maker-progress";
import { ReviewFlowPanel } from "@/components/review-flow-panel";
import { getTripBuildSettings } from "@/lib/build-settings";
import { hasConfirmedBuildSettings } from "@/lib/maker-flow";
import { getMakerTrip } from "@/lib/trips";
import { listTripUploads } from "@/lib/uploads";

export default async function ReviewPage({
  params,
  searchParams
}: {
  params: Promise<{ tripId: string }>;
  searchParams: Promise<{ saved?: string; error?: string }>;
}) {
  const { tripId } = await params;
  const { saved, error } = await searchParams;
  const trip = await getMakerTrip(tripId);
  const uploads = trip.isDemo ? [] : await listTripUploads(tripId);
  const settings = await getTripBuildSettings(tripId);
  const hasBuildSettings = hasConfirmedBuildSettings(settings);

  return (
    <main className="min-h-screen bg-paper px-6 py-8 md:px-10">
      <div className="mx-auto max-w-6xl">
        <header className="border-b border-ink/10 pb-6">
          <h1 className="text-4xl font-semibold text-ink">
            App sections
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-6 text-ink/65">
            Choose the sections {trip.name} should include before Roamwoven
            builds the first draft.
          </p>
        </header>

        <MakerProgress
          completedSteps={hasBuildSettings ? 3 : uploads.length > 0 ? 2 : 1}
          currentStep={3}
          detail="Recommended sections start on. Turn off anything that does not belong in this traveler app."
          maxAccessibleStep={hasBuildSettings ? 4 : uploads.length > 0 ? 3 : 2}
          tripId={tripId}
        />

        <ReviewFlowPanel
          trip={trip}
          uploads={uploads}
          settings={settings}
          saved={saved === "settings"}
          error={Boolean(error)}
        />
      </div>
    </main>
  );
}
