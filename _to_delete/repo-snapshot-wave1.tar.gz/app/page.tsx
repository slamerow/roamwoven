import Link from "next/link";
import { ArrowRight, Hammer, Route, ShieldCheck } from "lucide-react";

const steps = [
  "Create your trip",
  "Unlock the build",
  "Upload your info",
  "Confirm the details",
  "Generate and publish your app"
];

const perfectFor = [
  {
    title: "Solo travel",
    description:
      "Stay oriented without relying on someone else to remember the plan, the address, or what comes next."
  },
  {
    title: "Couples trips",
    description:
      "Make the once-or-twice-a-year trip feel effortless, with reservations, ideas, and daily logistics in one shared place."
  },
  {
    title: "Family adventures",
    description:
      "Keep kids, grandparents, and follow-along family in the loop, with an easy place to share pictures from the trip."
  }
];

const craftNotes = [
  {
    title: "Made from YOUR plans",
    description:
      "Simply drag and drop the confirmations, notes, screenshots, and documents you already have.",
    icon: Hammer
  },
  {
    title: "Organized for the actual trip",
    description:
      "Roamwoven turns scattered trip details into a clear app organized by day, place, and type of plan.",
    icon: Route
  },
  {
    title: "Bring people along",
    description:
      "Let friends and family follow along, see updates, and share photos while your trip details stay protected.",
    icon: ShieldCheck
  }
];

const demoPanels = [
  {
    eyebrow: "Today",
    title: "See what is happening today",
    description:
      "The Today screen shows flights, check-ins, activities, meals, and notes in the order you need them.",
    image: "/demo/example-today.jpg"
  },
  {
    eyebrow: "Details",
    title: "Open the details when you need them",
    description:
      "Confirmation numbers, addresses, links, notes, and context live inside the right card instead of buried in your inbox.",
    image: "/demo/example-detail.jpg"
  },
  {
    eyebrow: "Browse",
    title: "Find plans by day, place, or type",
    description:
      "Jump to a city, a travel day, every meal plan, or the one reservation you are trying to find.",
    image: "/demo/example-calendar.jpg"
  },
  {
    eyebrow: "Tools",
    title: "Keep practical tools close",
    description:
      "Search, weather, maps, useful phrases, and route context stay nearby without turning the app into clutter.",
    image: "/demo/example-map.jpg"
  },
  {
    eyebrow: "Photos",
    title: "Share photos with your people",
    description:
      "Friends and family can follow the trip through pictures organized by place, date, and moment.",
    image: null
  }
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-paper">
      <header className="absolute left-0 right-0 top-0 z-10">
        <div className="mx-auto flex max-w-6xl items-center justify-end px-6 py-5 md:px-10">
          <Link
            href="/login?next=%2Fmaker"
            className="rounded-md border border-ink/20 bg-paper/80 px-4 py-2 text-sm font-semibold text-ink backdrop-blur"
          >
            Log in
          </Link>
        </div>
      </header>
      <section className="mx-auto grid min-h-screen max-w-6xl grid-cols-1 content-center gap-10 px-6 py-10 md:grid-cols-[1.05fr_0.95fr] md:px-10">
        <div className="flex flex-col justify-center">
          <h1 className="max-w-3xl text-5xl font-semibold leading-tight text-ink md:text-7xl">
            The superapp for your next adventure
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink/75">
            All the information you need, right at your fingertips. It&apos;s
            vacation. Don&apos;t waste time digging through emails and PDFs.
          </p>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-ink/75">
            Roamwoven is a custom one-stop shop for your travels: flight and
            hotel info, itinerary details, useful phrases, and everything you
            need, never more than two or three clicks away.
          </p>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-ink/75">
            I&apos;m a travel planning nerd. When I took my family on a five-month
            sabbatical across 11 countries, I used AI to build the travel app
            of my dreams. Roamwoven lets you build your own travel superapp in
            just 15 to 20 minutes.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/maker"
              className="inline-flex items-center gap-2 rounded-md bg-ink px-5 py-3 text-sm font-semibold text-paper"
            >
              Start a trip
              <ArrowRight size={18} />
            </Link>
            <Link
              href="/t/demo"
              className="inline-flex items-center gap-2 rounded-md border border-ink/20 px-5 py-3 text-sm font-semibold text-ink"
            >
              View demo app
            </Link>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center gap-4">
          <DemoClip
            alt="Example Today screen in a generated trip app"
            image="/demo/example-today.jpg"
          />
          <p className="max-w-xs text-center text-sm leading-6 text-ink/60">
            A real traveler-app style Today screen: the day&apos;s plans,
            cards, tools, and trip navigation in one pocket-sized place.
          </p>
        </div>
      </section>

      <section className="border-y border-ink/10 bg-ink text-paper">
        <div className="mx-auto grid max-w-6xl gap-4 px-6 py-8 md:grid-cols-3 md:px-10">
          {craftNotes.map((note) => {
            const Icon = note.icon;
            return (
              <article
                className="rounded-md border border-paper/15 bg-paper/5 p-5"
                key={note.title}
              >
                <Icon className="text-flax" size={22} />
                <h2 className="mt-4 text-xl font-semibold text-paper">
                  {note.title}
                </h2>
                <p className="mt-2 text-sm leading-6 text-paper/70">
                  {note.description}
                </p>
              </article>
            );
          })}
        </div>
      </section>

      <section className="border-t border-ink/10 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-14 md:px-10">
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-moss">
            Perfect for
          </p>
          <div className="mt-5 grid gap-4 md:grid-cols-3">
            {perfectFor.map((item) => (
              <article
                className="rounded-md border border-ink/10 bg-paper p-5"
                key={item.title}
              >
                <h2 className="text-xl font-semibold text-ink">
                  {item.title}
                </h2>
                <p className="mt-3 text-sm leading-6 text-ink/65">
                  {item.description}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-ink/10 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-14 md:px-10">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-moss">
              What it can do
            </p>
            <h2 className="mt-3 text-4xl font-semibold leading-tight text-ink md:text-5xl">
              Know what is happening today.
            </h2>
            <p className="mt-4 text-lg leading-8 text-ink/70">
              Your app starts with the current day, then keeps the rest of the
              trip easy to reach: details, dates, places, maps, phrases,
              weather, and photos for friends and family following along.
            </p>
          </div>

          <div className="mt-10 grid gap-5 lg:grid-cols-2">
            {demoPanels.map((panel, index) => (
              <article
                className={
                  index === 0
                    ? "grid gap-6 rounded-md border border-ink/10 bg-paper p-5 md:grid-cols-[0.7fr_1fr] lg:col-span-2"
                    : "grid gap-5 rounded-md border border-ink/10 bg-paper p-5 md:grid-cols-[0.62fr_1fr]"
                }
                key={panel.title}
              >
                <div className="md:row-span-2">
                  {panel.image ? (
                    <DemoClip alt={`${panel.title} demo`} image={panel.image} />
                  ) : (
                    <PhotoPlaceholder />
                  )}
                </div>
                <div className="self-center">
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-clay">
                    {panel.eyebrow}
                  </p>
                  <h3 className="mt-2 text-2xl font-semibold text-ink">
                    {panel.title}
                  </h3>
                  <p className="mt-3 text-sm leading-6 text-ink/65">
                    {panel.description}
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-ink/10 bg-white">
        <div className="mx-auto grid max-w-6xl gap-4 px-6 py-10 md:grid-cols-5 md:px-10">
          {steps.map((step, index) => (
            <div key={step} className="rounded-md border border-ink/10 p-4">
              <p className="text-sm font-semibold text-clay">0{index + 1}</p>
              <p className="mt-3 text-sm font-semibold text-ink">{step}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

function DemoClip({ alt, image }: { alt: string; image: string }) {
  return (
    <div className="mx-auto aspect-[390/844] max-w-[210px] overflow-hidden rounded-[28px] border-[8px] border-ink bg-white shadow-xl ring-1 ring-flax/40">
      <img alt={alt} className="h-full w-full object-cover" src={image} />
    </div>
  );
}

function PhotoPlaceholder() {
  return (
    <div className="mx-auto aspect-[390/844] max-w-[210px] overflow-hidden rounded-[28px] border-[8px] border-ink bg-white shadow-xl">
      <div className="flex h-full flex-col bg-paper p-4">
        <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-moss">
          Photo album
        </p>
        <h4 className="mt-1 text-lg font-semibold text-ink">
          Follow along by place and date
        </h4>
        <div className="mt-5 grid grid-cols-2 gap-2">
          {["Kyoto", "Hoi An", "Bangkok", "Tokyo"].map((label, index) => (
            <div
              className="aspect-square rounded-md bg-ink p-2 text-paper"
              key={label}
            >
              <p className="text-[10px] font-semibold">Day {index + 12}</p>
              <p className="mt-10 text-xs font-semibold">{label}</p>
            </div>
          ))}
        </div>
        <p className="mt-auto rounded-md bg-white px-3 py-2 text-[11px] leading-4 text-ink/60">
          Friends and family can follow the trip through a simple, organized
          album.
        </p>
      </div>
    </div>
  );
}
