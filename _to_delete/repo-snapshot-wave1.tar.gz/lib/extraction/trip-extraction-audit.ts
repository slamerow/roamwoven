import type { StructuredTripRecords } from "@/lib/generated-trip-model";
import type { EvidenceArtifactBundle } from "@/lib/extraction/evidence-artifacts";
import { createGeneratedTripSummaryView } from "@/lib/generated-trip-summary";
import {
  canonicalizeSourceTransportAnchors,
  getSourceTransportAnchorsFromDraft,
  getSourceTransportAnchorsFromUsage,
} from "@/lib/extraction/source-transport-anchors";
import { createAuditDiagnostics } from "@/lib/extraction/trip-extraction-audit-diagnostics";
import { createAuditLineageRows } from "@/lib/extraction/trip-extraction-audit-lineage";
import {
  createCanonicalizationSummary,
  createDraftAuditSnapshot,
  createExtractionSummary,
} from "@/lib/extraction/trip-extraction-audit-snapshot";
import { createTripExtractionFingerprints } from "@/lib/extraction/trip-extraction-fingerprint";
import type { TripExtractionAuditReport } from "@/lib/extraction/trip-extraction-audit-types";

export { createDraftAuditSnapshot };
export type {
  DraftAuditSnapshot,
  TripExtractionAuditDiagnostic,
  TripExtractionAuditLineageRow,
  TripExtractionAuditReport,
} from "@/lib/extraction/trip-extraction-audit-types";

export function createTripExtractionAuditReport({
  evidenceArtifacts,
  draft,
  records,
  usage,
}: {
  evidenceArtifacts?: EvidenceArtifactBundle | null;
  draft: unknown;
  records: StructuredTripRecords;
  usage?: unknown;
}): TripExtractionAuditReport {
  const summary = createGeneratedTripSummaryView(records);
  const activeItems = records.items.filter((item) => item.status !== "ignored");
  const primaryItems = activeItems.filter((item) => !item.parentItemId);
  const warnings = summary.warnings.map((warning) => ({
    code: warning.code,
    severity: warning.severity,
    subjectId: warning.subjectId,
    subjectType: warning.subjectType,
    title: warning.title,
  }));
  const lineage = createAuditLineageRows({
    artifacts: evidenceArtifacts,
    records,
    usage,
  });
  const sourceTransportAnchors = canonicalizeSourceTransportAnchors([
    ...getSourceTransportAnchorsFromDraft(draft),
    ...getSourceTransportAnchorsFromUsage(usage),
  ]);
  const canonicalization = createCanonicalizationSummary(usage);

  return {
    canonicalization,
    diagnostics: createAuditDiagnostics({
      undisposedObservationCount: canonicalization.undisposedObservationCount,
      lineage,
      records,
      sourceTransportAnchors,
      usage,
    }),
    detectorIncidents: lineage.flatMap((row) =>
      row.matchMethod === "semantic_fallback" && row.canonicalPieceId && row.finalRecords[0]
        ? [{
            canonicalPieceId: row.canonicalPieceId,
            code: "canonical_identity_semantic_fallback" as const,
            detail: `Canonical ID did not join, but independent typed evidence uniquely matched ${row.finalRecords[0].recordType} ${row.finalRecords[0].title}.`,
            finalRecordId: row.finalRecords[0].id,
          }]
        : []
    ),
    draft: createDraftAuditSnapshot(draft),
    extraction: createExtractionSummary(usage),
    fingerprints: createTripExtractionFingerprints(records),
    lineage,
    sourceAnchors: {
      transport: sourceTransportAnchors,
    },
    structured: {
      activeActivities: primaryItems.filter((item) => item.itemType === "activity")
        .length,
      activeNotes: primaryItems.filter((item) => item.itemType === "note").length,
      groupedStops: activeItems.filter((item) => Boolean(item.parentItemId)).length,
      hardWarnings: warnings.filter((warning) => warning.severity === "hard")
        .length,
      openQuestions: records.reviewQuestions.filter(
        (question) => question.status === "open"
      ).length,
      quietWarnings: warnings.filter((warning) => warning.severity === "quiet")
        .length,
      stays: records.stays.filter((stay) => stay.status !== "ignored").length,
      transport: records.transport.filter((item) => item.status !== "ignored")
        .length,
    },
    warnings,
  };
}
