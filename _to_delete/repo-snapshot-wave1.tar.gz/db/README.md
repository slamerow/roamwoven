# Database Notes

`schema.sql` is the current draft schema. It includes the V1 trip lifecycle fields for payment status, theme pack, password flags, photo metrics, token rotation, and sensitive-field visibility.

Ownership is part of the schema, not just app code:

- `trips.owner_user_id` is required and references `auth.users`.
- Maker tables have Row Level Security enabled.
- Trip-owned child tables are protected through policies that check the owning trip.
- Owner/trip/date indexes are included so dashboard and itinerary queries can scale beyond a small beta.
- Normal maker reads/writes should use the user-scoped Supabase server client.
- Service-role access is reserved for trusted backend jobs, such as Stripe webhook payment updates.
- `trip_payment_events` records checkout/session/payment-intent metadata idempotently before a trip is marked paid.
- `trip_processing_runs` logs explicit parsing attempts, model/usage metadata, and failure states.
- `trip_material_extractions` checkpoints each uploaded material before the model call, including text-ready/OCR-needed/unsupported/failed status and extracted text when available.
- `trip_material_ocr_batches` stores resumable page ranges, completion status, model/config, usage, and full batch text so incomplete OCR cannot masquerade as text-ready.
- `trip_evidence_observations` stores each source sighting from spine/chunk/source-anchor extraction.
- `trip_canonical_pieces` stores the canonical Lego pieces, field-level provenance, conflicts, and output eligibility that assembly consumes.
- `trip_draft_snapshots` stores raw parser JSON drafts before those drafts are converted into editable trip records.
- `published_trip_private_details` stores server-only protected values for active traveler snapshots; public snapshot JSON should stay redacted.

The next database step is to turn this into real Supabase migrations and wire:

1. Auth.
2. Owner-scoped trip creation.
3. Dashboard trip listing.
4. Upload records.
5. Published trip snapshots.
6. Production-safe extraction migrations before enabling `ROAMWOVEN_ENABLE_AI_EXTRACTION`.

The prototype must keep building without Supabase env vars. In that mode, maker routes use the Wren's Adventure demo trip while the production code paths remain Supabase-ready.

## Production Patches

- `production-sql-2026-06-18-review-decisions-and-snapshots.sql`: additive patch for `trip_review_decisions`, `published_trip_snapshots`, and `trips.published_snapshot_id`. Run this before testing deployed review decisions or published traveler snapshots.
- `production-sql-2026-06-18-durability-foundations.sql`: additive patch for payment event audit rows, review-decision idempotency keys, and soft-delete recovery metadata. Run this before deploying the durability foundation code.
- `production-sql-2026-06-19-material-extraction-checkpoints.sql`: additive patch for `trip_material_extractions`. Run this before deploying code that checkpoints uploaded materials during extraction.
- `production-sql-2026-07-08-processing-transactions-and-events.sql`: additive patch for queryable processing events plus transactional extraction completion/failure and publish snapshot commits. Run this before deploying the matching transaction/RPC application code.
- `production-sql-2026-07-10-ocr-evidence-foundations.sql`: additive patch for durable OCR page batches, evidence observations, and canonical pieces. Run this before deploying the P0 OCR/evidence code.
