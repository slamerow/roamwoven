import assert from "node:assert/strict";
import {
  clusterExtractedEvidence,
  reapplyCanonicalOutputInvariants,
  type EvidenceStageInput,
} from "@/lib/extraction/evidence-clustering";
import { prepareCanonicalEvidencePieces } from "@/lib/extraction/canonical-trip-assembly";
import type { SourceTransportAnchor } from "@/lib/extraction/source-transport-anchors";

async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    console.log(`ok - ${name}`);
  } catch (error) {
    console.error(`not ok - ${name}`);
    throw error;
  }
}

function activity({
  category = "food_dining",
  city = "Sample City",
  date = "2030-04-12",
  description = null,
  sourceFilename,
  startTime = null,
  title,
}: {
  category?: string;
  city?: string | null;
  date?: string;
  description?: string | null;
  sourceFilename: string;
  startTime?: string | null;
  title: string;
}) {
  return {
    address: null,
    category,
    city,
    date,
    description,
    endTime: null,
    itemType: "activity",
    sourceFilename,
    startTime,
    title,
  };
}

function stage(label: string, value: Record<string, unknown>): EvidenceStageInput {
  return {
    label,
    source: "model_chunk",
    sourceFilename: `${label}.txt`,
    stage: value,
  };
}

function emptyStage(overrides: Record<string, unknown> = {}) {
  return {
    activities: [],
    missingDetails: [],
    places: [],
    sensitiveDetails: [],
    stays: [],
    transport: [],
    ...overrides,
  };
}

function anchor(overrides: Partial<SourceTransportAnchor>): SourceTransportAnchor {
  return {
    anchorId: "anchor-1",
    arrivalLocation: null,
    arrivalTime: null,
    confidence: "high",
    confirmation: null,
    date: "2030-04-13",
    departureLocation: null,
    departureTime: null,
    evidence: "source evidence",
    kind: "train",
    number: null,
    provider: null,
    provenance: ["ocr"],
    routeLabel: "Train",
    sourceFilename: "source.pdf",
    sourceUploadId: "upload-1",
    ...overrides,
  };
}

export default async function run() {
  await test("three source sightings become one canonical booked activity", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "itinerary",
          emptyStage({
            activities: [
              activity({
                description: "Lunch is planned for 1 PM.",
                sourceFilename: "itinerary.pdf",
                startTime: "13:00",
                title: "Lunch at Harbor House",
              }),
            ],
          })
        ),
        stage(
          "reservation OCR",
          emptyStage({
            activities: [
              activity({
                description: "Reservation for two guests.",
                sourceFilename: "reservation.png",
                startTime: "13:00",
                title: "Harbor House",
              }),
            ],
          })
        ),
        stage(
          "prose",
          emptyStage({
            activities: [
              activity({
                sourceFilename: "notes.txt",
                startTime: "13:00",
                title: "Harbor House lunch",
              }),
            ],
          })
        ),
      ],
      tripOverview: {},
    });
    const activities = (result.draft as { activities: unknown[] }).activities;
    const piece = result.pieces.find((candidate) => candidate.kind === "activity");

    assert.equal(activities.length, 1);
    assert.equal(piece?.observationIds.length, 3);
    assert.equal(piece?.payload.startTime, "13:00");
    assert.match(String(piece?.payload.description), /Reservation for two guests/);
  });

  await test("distinct same-site stops remain separate pieces for assembly grouping", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "same-site day",
          emptyStage({
            activities: [
              activity({
                sourceFilename: "plan.pdf",
                title: "River Palace",
              }),
              activity({
                sourceFilename: "plan.pdf",
                title: "River Palace Gardens",
              }),
            ],
          })
        ),
      ],
      tripOverview: {},
    });

    assert.equal(
      result.pieces.filter(
        (piece) => piece.kind === "activity" && piece.outputEligible
      ).length,
      2
    );
  });

  await test("repeated visits to the same city remain separate dated place pieces", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "trip spine",
          emptyStage({
            places: [
              {
                arriveDate: "2030-04-12",
                city: "Rome",
                country: "Italy",
                leaveDate: "2030-04-14",
              },
              {
                arriveDate: "2030-04-20",
                city: "Rome",
                country: "Italy",
                leaveDate: "2030-04-21",
              },
            ],
          })
        ),
        stage(
          "supporting chunks",
          emptyStage({
            places: [
              {
                arriveDate: "2030-04-12",
                city: "Rome",
                country: "Italy",
                leaveDate: "2030-04-14",
              },
              {
                arriveDate: "2030-04-20",
                city: "Rome",
                country: "Italy",
                leaveDate: "2030-04-21",
              },
            ],
          })
        ),
      ],
      tripOverview: {},
    });
    const places = (result.draft as { places: Array<Record<string, unknown>> })
      .places;

    assert.equal(places.length, 2);
    assert.deepEqual(
      places.map((place) => place.arriveDate),
      ["2030-04-12", "2030-04-20"]
    );
  });

  await test("source overview containers do not become traveler activities", () => {
    const childOne = activity({
      sourceFilename: "plan.pdf",
      title: "Market Hall",
    });
    const childTwo = activity({
      sourceFilename: "plan.pdf",
      title: "Old Library",
    });
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "day plan",
          emptyStage({
            activities: [
              activity({
                description: "Visit Market Hall, then Old Library.",
                sourceFilename: "plan.pdf",
                title: "Sample City day",
              }),
              childOne,
              childTwo,
            ],
          })
        ),
      ],
      tripOverview: {},
    });

    assert.equal((result.draft as { activities: unknown[] }).activities.length, 2);
    assert.equal(result.summary.contextObservationCount, 1);
  });

  await test("connecting segments sharing a confirmation stay separate", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "return flights",
          emptyStage({
            transport: [
              {
                arrival: "HUB",
                arrivalTime: "18:00",
                confirmation: "SAME123",
                date: "2030-04-20",
                departure: "AAA",
                departureTime: "14:00",
                description: null,
                provider: "Example Air 100",
                sourceFilename: "ticket.pdf",
                title: "AAA to HUB",
                type: "flight",
              },
              {
                arrival: "BBB",
                arrivalTime: "21:00",
                confirmation: "SAME123",
                date: "2030-04-20",
                departure: "HUB",
                departureTime: "19:30",
                description: null,
                provider: "Example Air 200",
                sourceFilename: "ticket.pdf",
                title: "HUB to BBB",
                type: "flight",
              },
            ],
          })
        ),
      ],
      tripOverview: {},
    });

    assert.equal((result.draft as { transport: unknown[] }).transport.length, 2);
  });

  await test("written and ISO transport dates cluster before assembly", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [
        anchor({
          anchorId: "vienna-train-anchor",
          arrivalLocation: "Vienna",
          arrivalTime: "13:23",
          confirmation: "1beb5005",
          date: "2019-01-18",
          departureLocation: "Train",
          departureTime: "09:20",
          number: "RJ 1033",
          routeLabel: "Train to Vienna",
        }),
      ],
      stages: [
        stage(
          "written-date-train",
          emptyStage({
            transport: [
              {
                arrival: "Wien Hauptbahnhof",
                arrivalTime: "13:23",
                confirmation: "1beb5005",
                date: "January 18th",
                departure: "Praha Hlavni Nadrazi",
                departureTime: "9:20 AM",
                provider: "RegioJet",
                title: "Prague to Vienna train",
                type: "train",
              },
            ],
          })
        ),
      ],
      tripOverview: {
        dateRange: "January 12-25, 2019",
        title: "Central Europe",
      },
    });
    const transports = (result.draft as {
      transport: Array<Record<string, unknown>>;
    }).transport;

    assert.equal(transports.length, 1);
    assert.equal(transports[0]?.date, "2019-01-18");
    assert.equal(transports[0]?.departure, "Praha Hlavni Nadrazi");
    assert.equal(transports[0]?.departureTime, "09:20");
    assert.equal(result.pieces.find((piece) => piece.kind === "transport")?.observationIds.length, 2);
  });

  await test("source anchors enrich a matching piece but weak anchors cannot manufacture rows", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [
        anchor({
          anchorId: "train-anchor",
          arrivalLocation: "Central Station",
          arrivalTime: "13:20",
          departureLocation: "Main Station",
          departureTime: "09:15",
          routeLabel: "Main Station to Central Station",
        }),
        anchor({
          anchorId: "budget-anchor",
          kind: "flight",
          provider: "Budget estimate",
          routeLabel: "Flight to Sample City",
        }),
      ],
      stages: [
        stage(
          "transport",
          emptyStage({
            transport: [
              {
                arrival: "Central Station",
                arrivalTime: null,
                confirmation: null,
                date: "2030-04-13",
                departure: "Main Station",
                departureTime: null,
                description: null,
                provider: null,
                sourceFilename: "itinerary.pdf",
                title: "Train to Central Station",
                type: "train",
              },
            ],
          })
        ),
      ],
      tripOverview: {},
    });
    const transport = (result.draft as { transport: Array<Record<string, unknown>> })
      .transport;

    assert.equal(transport.length, 1);
    assert.equal(transport[0]?.departureTime, "09:15");
    assert.equal(transport[0]?.arrivalTime, "13:20");
    assert.equal(result.summary.suppressedWeakAnchorCount, 1);
  });

  await test("corrupt source fragments cannot become standalone transport rows", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [
        anchor({
          anchorId: "corrupt-budget-fragment",
          arrivalLocation: "Rome",
          arrivalTime: "21:50",
          confirmation: null,
          date: "2030-04-20",
          departureLocation: "-> 9:50 PM",
          departureTime: "20:30",
          evidence: "Costs Travel budget. Flight to Rome: $300.",
          kind: "flight",
          routeLabel: "Flight Flight to Rome",
        }),
        anchor({
          anchorId: "corrupt-lockbox-fragment",
          arrivalLocation: null,
          confirmation: "2580",
          date: "2030-04-20",
          departureLocation: null,
          departureTime: "15:00",
          evidence: "Lockbox code 2580. The key will be prepared at 3 PM.",
          routeLabel: "Train",
        }),
      ],
      stages: [stage("empty", emptyStage())],
      tripOverview: {},
    });

    assert.equal((result.draft as { transport: unknown[] }).transport.length, 0);
    assert.equal(result.summary.suppressedWeakAnchorCount, 2);
  });

  await test("canonical facts suppress source-obvious review questions", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "review policy",
          emptyStage({
            activities: [
              activity({
                sourceFilename: "plan.pdf",
                startTime: "19:00",
                title: "Harbor House",
              }),
            ],
            missingDetails: [
              {
                answerType: "date",
                confidence: "medium",
                evidence: "Trip dates are printed in the source.",
                guessedValue: null,
                prompt: "What are the trip dates?",
                reason: "Needed for the app.",
                relatedTitle: null,
                subjectType: "trip",
                targetField: "dateRange",
              },
              {
                answerType: "time",
                confidence: "medium",
                evidence: "Dinner is listed at 7 PM.",
                guessedValue: null,
                prompt: "What time is Harbor House?",
                reason: "Needed for the timeline.",
                relatedTitle: "Harbor House",
                subjectType: "item",
                targetField: "startTime",
              },
              {
                answerType: "confirm",
                confidence: "low",
                evidence: "Ticket purchase is unresolved.",
                guessedValue: null,
                prompt: "Should we buy the optional tower ticket?",
                reason: "The choice changes the traveler plan.",
                relatedTitle: "Harbor House",
                subjectType: "item",
                targetField: "ticketDecision",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "April 12-20, 2030" },
    });
    const missingDetails = (result.draft as { missingDetails: unknown[] })
      .missingDetails as Array<{ prompt?: string }>;

    assert.deepEqual(
      missingDetails.map((detail) => detail.prompt),
      ["Should we buy the optional tower ticket?"]
    );
  });

  await test("dated source structure resolves item dates before review", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "dated section",
          emptyStage({
            activities: [{
              category: "art_culture",
              city: "Prague",
              date: null,
              description: "Visit St. Barbara's Church.",
              evidenceRole: "atomic_candidate",
              itemType: "activity",
              sourceHeadingPath: ["Thursday, 17.1.2019"],
              sourceSectionLabel: "Thursday, 17.1.2019",
              sourceSectionType: "dated_itinerary",
              title: "St. Barbara's Church",
            }],
            missingDetails: [{
              answerOptions: [
                { label: "January 16", value: "2019-01-16" },
                { label: "January 17", value: "2019-01-17" },
              ],
              answerType: "single_choice",
              prompt: "Does St. Barbara's Church happen January 16 or 17?",
              relatedTitle: "St. Barbara's Church",
              subjectType: "item",
              targetField: "date",
            }],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };

    assert.equal(draft.activities[0]?.date, "2019-01-17");
    assert.equal(draft.missingDetails.length, 0);
  });

  await test("date-shaped note labels cannot become cards or Questions", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("date label", emptyStage({
        missingDetails: [{
          answerType: "date",
          evidence: "The source contains the dated heading 17.1.2019.",
          prompt: "What date is the 17.1.2019 note?",
          reason: "The source lists this note.",
          relatedTitle: "17.1.2019 note",
          subjectType: "item",
          targetField: "date",
        }],
        places: [{
          arriveDate: "2019-01-16",
          city: "Prague",
          leaveDate: "2019-01-18",
        }],
        stays: [{
          checkIn: "2019-01-16",
          checkOut: "2019-01-18",
          city: "Prague",
          name: "Prague Hotel",
        }],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };

    assert.equal(draft.activities.length, 0);
    assert.equal(draft.missingDetails.length, 0);
  });

  await test("explicit source ticket TODO survives an omitted model sentence", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [{
        label: "Prague Castle",
        source: "model_chunk",
        sourceFilename: "itinerary.pdf",
        sourceText: [
          "Wednesday, January 16, 2019",
          "Prague Castle",
          "Which ticket to get?",
        ].join("\n"),
        stage: emptyStage({
          activities: [{
            category: "tours_tickets",
            city: "Prague",
            date: "2019-01-16",
            description: "Visit Prague Castle.",
            evidenceRole: "atomic_candidate",
            itemType: "activity",
            sourceSectionType: "dated_itinerary",
            title: "Prague Castle",
          }],
        }),
      }],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };

    assert.equal(draft.activities[0]?.description, "Visit Prague Castle.");
    assert.equal(draft.missingDetails.length, 1);
    assert.equal(
      draft.missingDetails[0]?.prompt,
      "Which ticket or tour option should be listed for Prague Castle?"
    );
    const decision = result.observations.find(
      (observation) => observation.kind === "decision"
    );
    assert.ok(decision);
    assert.equal(decision.payload.decisionType, "ticket_choice");
    assert.equal(decision.disposition?.outcome, "declared_detail");
  });

  await test("city-note lists preserve hidden entry identity without overlapping activities", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [{
        label: "Budapest food notes",
        source: "model_chunk",
        sourceFilename: "notes.txt",
        stage: emptyStage({
          activities: [
            {
              category: "food_dining",
              city: "Budapest",
              date: "2019-01-22",
              description: "Dinner reservation at 8 PM.",
              evidenceRole: "atomic_candidate",
              itemType: "activity",
              startTime: "20:00",
              title: "Borkonyha Winekitchen dinner",
            },
            {
              category: "food_dining",
              city: "Budapest",
              description: "Restaurants: Borkonyha Winekitchen, Rosenstein, Menza",
              evidenceRole: "city_note_candidate",
              itemType: "note",
              sourceSectionType: "city_reference",
              title: "Budapest restaurant ideas",
            },
          ],
          places: [{
            arriveDate: "2019-01-21",
            city: "Budapest",
            leaveDate: "2019-01-24",
          }],
        }),
      }],
      tripOverview: { dateRange: "January 21-24, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
    };
    const note = draft.activities.find(
      (item) => item.title === "Budapest Notes & Tips"
    );
    const entryPieces = result.pieces.filter(
      (piece) => piece.payload._canonicalNoteEntry === true
    );

    assert.equal(entryPieces.length, 3);
    assert.equal(entryPieces.every((piece) => !piece.outputEligible), true);
    assert.equal(
      entryPieces.some(
        (piece) =>
          /Borkonyha/i.test(String(piece.payload.title)) &&
          !piece.outputEligible
      ),
      true
    );
    assert.equal(/Borkonyha/i.test(String(note?.description)), false);
    // 2026-07-17 evening: city notes render Eli-approved universal sections;
    // the source's "Restaurants" list lands in the Food section.
    assert.equal(note?.description, "Food: Rosenstein, Menza");
    assert.equal(
      result.observations.some(
        (observation) =>
          observation.kind === "context" &&
          Array.isArray(observation.payload._canonicalNoteEntries)
      ),
      true
    );
  });

  await test("a single city-note collection cannot collide with its source identity", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [{
        label: "Kyoto notes",
        source: "model_chunk",
        sourceFilename: "notes.txt",
        stage: emptyStage({
          activities: [{
            category: "local_tips",
            city: "Kyoto",
            description: "Keep some cash for small temples.",
            evidenceRole: "city_note_candidate",
            itemType: "note",
            sourceSectionType: "city_reference",
            title: "Kyoto practical tip",
          }],
          places: [{
            arriveDate: "2031-04-03",
            city: "Kyoto",
            leaveDate: "2031-04-06",
          }],
        }),
      }],
      tripOverview: { dateRange: "April 3-6, 2031" },
    });

    const prepared = prepareCanonicalEvidencePieces(result.pieces);
    assert.equal(
      new Set(prepared.pieces.map((piece) => piece.id)).size,
      prepared.pieces.length
    );
    assert.equal(
      prepared.pieces.filter((piece) => piece.outputEligible).length,
      2
    );
  });

  await test("the canonical output retry is idempotent", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("retry", emptyStage({
        activities: [{
          category: "art_culture",
          city: "Paris",
          date: "2032-06-17",
          itemType: "activity",
          title: "Museum visit",
        }],
      }))],
      tripOverview: { dateRange: "June 16-18, 2032" },
    });
    const pieces = structuredClone(result.pieces);
    const activity = pieces.find(
      (piece) => piece.kind === "activity" && piece.outputEligible
    );
    assert.ok(activity);
    activity.payload.title = "Paris day plan";

    const first = reapplyCanonicalOutputInvariants({ pieces });
    const second = reapplyCanonicalOutputInvariants({ pieces: first.pieces });
    assert.equal(first.changed, true);
    assert.equal(second.changed, false);
  });

  await test("car reservation details attach to the canonical rental", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("rental", emptyStage({
        activities: [{
          category: "arrival_departure",
          city: "Prague",
          date: null,
          description: "Reservation confirmation CAR123.",
          itemType: "activity",
          sourceHeadingPath: ["Thursday, 17.1.2019"],
          sourceSectionLabel: "Thursday, 17.1.2019",
          sourceSectionType: "dated_itinerary",
          title: "Car reservation details",
        }],
        transport: [{
          arrival: "Prague",
          date: "2019-01-17",
          departure: "Prague",
          description: "Rental car for the day.",
          title: "Prague rental car",
          type: "rental_car",
        }],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
      transport: Array<Record<string, unknown>>;
    };

    assert.equal(
      draft.activities.some((item) => item.title === "Car reservation details"),
      false
    );
    assert.equal(draft.missingDetails.length, 0);
    const rental = draft.activities.find((item) => item.title === "Prague rental car");
    assert.ok(rental);
    assert.match(String(rental.description ?? ""), /CAR123/);
    assert.equal(draft.transport.length, 0);
  });

  await test("production title and time variants become one canonical activity", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "central-europe-lunch",
          emptyStage({
            activities: [
              activity({
                date: "2019-01-16",
                description: "Lunch at U Maliru at 1:00 PM.",
                sourceFilename: "itinerary.pdf",
                startTime: "1:00 PM",
                title: "U Maliru lunch",
              }),
              activity({
                date: "2019-01-16",
                description: "Reservation for one; three-course degustation.",
                sourceFilename: "ticket.pdf",
                startTime: "2019-01-16T13:00:00",
                title: "Lunch at U Malířů",
              }),
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const activities = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities;

    assert.equal(activities.length, 1);
    assert.equal(activities[0]?.startTime, "13:00");
    assert.match(String(activities[0]?.description), /degustation/i);
  });

  await test("same-day aliases merge while explicit cross-date visits stay separate", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "budapest-evidence",
          emptyStage({
            activities: [
              activity({
                date: "2019-01-21",
                description: "Gellert Baths.",
                sourceFilename: "plan.pdf",
                title: "Gellert Baths",
              }),
              activity({
                date: "2019-01-21",
                description: "Bath houses, including Gellert Baths.",
                sourceFilename: "plan.pdf",
                title: "Bath houses",
              }),
              activity({
                date: "2019-01-23",
                description:
                  "Gellert Bath House after the spa; return to the lobby for the cafe.",
                sourceFilename: "day-plan.pdf",
                title: "Gellert Bath House",
              }),
              activity({
                date: "2019-01-21",
                sourceFilename: "plan.pdf",
                title: "Pinball Museum",
              }),
              activity({
                date: "2019-01-23",
                sourceFilename: "day-plan.pdf",
                title: "Pinball Museum",
              }),
              activity({
                date: "2019-01-21",
                sourceFilename: "plan.pdf",
                title: "Great Synagogue",
              }),
              activity({
                date: "2019-01-21",
                sourceFilename: "plan.pdf",
                title: "Great Synagogue / Jewish History",
              }),
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<{ prompt?: string }>;
    };

    assert.equal(draft.activities.filter((item) => /gellert|bath house/i.test(String(item.title))).length, 2);
    // 2026-07-17 commitment rule: Pinball Museum repeats on two days with no
    // time, booking, or planned language on either copy — repeated but never
    // committed, so it has NO activity card and one city-note home.
    assert.equal(
      draft.activities.filter(
        (item) =>
          /pinball/i.test(String(item.title)) && item.itemType !== "note"
      ).length,
      0
    );
    assert.equal(
      draft.activities.filter(
        (item) =>
          item.itemType === "note" &&
          /pinball/i.test(
            `${String(item.title)} ${String(item.description ?? "")}`
          )
      ).length,
      1
    );
    assert.equal(draft.activities.filter((item) => /synagogue/i.test(String(item.title))).length, 1);
    assert.equal(
      draft.missingDetails.filter((item) => /Which day should/i.test(item.prompt ?? "")).length,
      0
    );
  });

  await test("separately booked visits to the same venue remain separate pieces", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "repeat-bookings",
          emptyStage({
            activities: [
              {
                ...activity({
                  date: "2019-01-21",
                  sourceFilename: "first-ticket.pdf",
                  startTime: "3:00 PM",
                  title: "Pinball Museum",
                }),
                confirmation: "PIN-ONE",
              },
              {
                ...activity({
                  date: "2019-01-23",
                  sourceFilename: "second-ticket.pdf",
                  startTime: "6:00 PM",
                  title: "Pinball Museum",
                }),
                confirmation: "PIN-TWO",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const activities = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities;

    assert.equal(
      activities.filter((item) => /pinball/i.test(String(item.title))).length,
      2
    );
  });

  await test("tickets and rental returns attach while stray access tasks are rejected", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "attachments",
          emptyStage({
            activities: [
              {
                category: "tours_tickets",
                date: "2019-01-15",
                description: "Klementinum guided tour at 2:30 PM.",
                itemType: "activity",
                startTime: "2:30 PM",
                title: "Klementinum Guided Tour",
              },
              {
                category: "tours_tickets",
                date: "2019-01-15",
                description: "Skip the line ticket.",
                itemType: "activity",
                startTime: "14:30",
                title: "Skip the line ticket",
              },
              {
                address: "Revoluční 1044/23",
                category: "arrival_departure",
                date: "2019-01-17",
                description: "Pick up the rental car at 9 AM.",
                itemType: "activity",
                startTime: "9:00 AM",
                title: "Pick up car for Kutna Hora",
              },
              {
                address: "Revoluční 1044/23, 110 00 Praha 1",
                category: "arrival_departure",
                date: "2019-01-17",
                description: "Return the car at the same location at 20:00.",
                endTime: "20:00",
                itemType: "activity",
                title: "Car return",
              },
              {
                category: "arrival_departure",
                date: "2019-01-24",
                description: "Key pickup from the lockbox.",
                itemType: "activity",
                title: "Collect apartment key",
              },
            ],
            places: [
              {
                arriveDate: "2019-01-14",
                city: "Prague",
                leaveDate: "2019-01-18",
              },
              {
                arriveDate: "2019-01-24",
                city: "Rome",
                leaveDate: "2019-01-25",
              },
            ],
            stays: [
              {
                checkIn: "2019-01-24",
                checkOut: "2019-01-25",
                name: "The RomeHello Hostel",
                stayType: "hostel",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const activities = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities;
    const klementinum = activities.find((item) => /Klementinum/i.test(String(item.title)));
    const rental = activities.find((item) => /Pick up car/i.test(String(item.title)));

    assert.ok(klementinum);
    assert.match(String(klementinum.description), /Skip the line ticket/i);
    assert.equal(activities.some((item) => /Skip the line ticket/i.test(String(item.title))), false);
    assert.ok(rental);
    assert.equal(rental.endTime, "20:00");
    assert.equal(rental.address, "Revoluční 1044/23, 110 00 Praha 1");
    assert.equal(activities.some((item) => /Car return/i.test(String(item.title))), false);
    assert.equal(activities.some((item) => /Collect apartment key/i.test(String(item.title))), false);
  });

  await test("a different rental return location cannot replace the pickup address", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "rental-locations",
          emptyStage({
            activities: [
              {
                address: "Pickup Road 1",
                category: "arrival_departure",
                date: "2019-01-17",
                description: "Pick up the rental car at 9 AM.",
                itemType: "activity",
                startTime: "9:00 AM",
                title: "Pick up car for Kutna Hora",
              },
              {
                address: "Return Road 99",
                category: "arrival_departure",
                date: "2019-01-17",
                description: "Return the car at the airport depot at 8 PM.",
                endTime: "8:00 PM",
                itemType: "activity",
                title: "Car return",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const rental = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities.find((item) => /Pick up car/i.test(String(item.title)));

    assert.ok(rental);
    assert.equal(rental.address, "Pickup Road 1");
    assert.match(String(rental.description), /Return location: Return Road 99/i);
  });

  await test("out-of-range model dates are removed without dropping named evidence", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "trip-range",
          emptyStage({
            places: [
              {
                arriveDate: "2019-01-13",
                city: "Rome",
                leaveDate: "2019-01-25",
              },
            ],
            transport: [
              {
                arrival: "FCO",
                arrivalTime: "10:15",
                date: "2019-05-08",
                departure: "JFK",
                departureTime: "19:46",
                number: "444",
                title: "Flight JFK to FCO",
                type: "flight",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });

    const transport = (result.draft as {
      transport: Array<Record<string, unknown>>;
    }).transport;

    assert.equal(transport.length, 1);
    assert.equal(transport[0]?.date, null);
    assert.equal(transport[0]?._recoveryRequired, true);
    assert.ok(
      result.pieces.some(
        (piece) =>
          piece.kind === "transport" &&
          piece.outputEligible &&
          piece.actions.some(
            (action) =>
              action.type === "recovered" &&
              /outside established trip range/.test(action.reason)
          )
      )
    );
  });

  await test("explicit same-site grouping preserves ordered children and independently timed stops", () => {
    const decisionId = "group_test_schonbrunn";
    const result = clusterExtractedEvidence({
      groupingDecisions: [{
        candidateIds: ["stage-1-item-1", "stage-1-item-2", "stage-1-item-3"],
        claim: "The source block and venue evidence identify one palace-complex visit.",
        decisionId,
        parentCandidateId: "stage-1-item-1",
        parentTitle: "Schönbrunn Palace complex",
        source: "canonical_resolver",
      }],
      sourceTransportAnchors: [],
      stages: [
        stage(
          "vienna-grouping",
          emptyStage({
            activities: [
              {
                category: "art_culture",
                date: "2019-01-19",
                description:
                  "Same-site Schönbrunn visit including Schönbrunn gardens and the Apple Strudel Show.",
                _canonicalGroupingDecisionIds: [decisionId],
                _resolverCandidateId: "stage-1-item-1",
                itemType: "activity",
                title: "Schönbrunn Palace complex",
              },
              {
                category: "art_culture",
                date: "2019-01-19",
                description: "Walk the gardens.",
                _resolverCandidateId: "stage-1-item-2",
                itemType: "activity",
                title: "Schönbrunn gardens",
              },
              {
                category: "tours_tickets",
                date: "2019-01-19",
                description: "Timed show inside the palace.",
                _resolverCandidateId: "stage-1-item-3",
                itemType: "activity",
                title: "Apple Strudel Show",
              },
              {
                category: "art_culture",
                date: "2019-01-19",
                description: "Visit Hundertwasser House.",
                _resolverCandidateId: "stage-1-item-4",
                itemType: "activity",
                title: "Hundertwasser House",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<{ prompt?: string }>;
    };

    const roots = draft.activities.filter(
      (item) => !item._canonicalParentPieceId
    );
    const children = draft.activities.filter(
      (item) => item._canonicalParentPieceId
    );
    assert.deepEqual(
      roots.map((item) => item.title).sort(),
      [
        "Apple Strudel Show",
        "Hundertwasser House",
        "Schönbrunn Palace complex",
      ].sort()
    );
    assert.deepEqual(
      children.map((item) => item.title),
      ["Schönbrunn gardens"]
    );
    assert.equal(
      String(roots.find((item) => item.title === "Schönbrunn Palace complex")?.description ?? "")
        .includes("Walk the gardens"),
      false
    );
    assert.equal(
      draft.missingDetails.filter((item) => /one activity card/i.test(item.prompt ?? "")).length,
      1
    );
  });

  await test("model-only grouping language cannot merge or create a Call", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "clean-day-control",
          emptyStage({
            activities: [
              {
                category: "art_culture",
                date: "2031-04-02",
                description: "Vienna day including Albertina and Prater Ferris Wheel.",
                evidenceRole: "grouping_proposal",
                itemType: "activity",
                title: "Vienna sights",
              },
              {
                category: "art_culture",
                date: "2031-04-02",
                itemType: "activity",
                title: "Albertina",
              },
              {
                category: "art_culture",
                date: "2031-04-02",
                itemType: "activity",
                title: "Prater Ferris Wheel",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "April 1-4, 2031" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<{ prompt?: string }>;
    };

    assert.deepEqual(
      draft.activities.map((item) => item.title),
      ["Albertina", "Prater Ferris Wheel"]
    );
    assert.equal(
      draft.missingDetails.some((item) => /one activity card/i.test(item.prompt ?? "")),
      false
    );
  });

  await test("a booked same-site parent keeps its booking while owning untimed stops", () => {
    const decisionId = "group_booked_parent";
    const result = clusterExtractedEvidence({
      groupingDecisions: [{
        candidateIds: ["stage-1-item-1", "stage-1-item-2", "stage-1-item-3"],
        claim: "The booking covers one same-site palace-complex visit.",
        decisionId,
        parentCandidateId: "stage-1-item-1",
        parentTitle: "River Palace visit",
        source: "canonical_resolver",
      }],
      sourceTransportAnchors: [],
      stages: [stage("booked parent", emptyStage({
        activities: [
          {
            ...activity({
              date: "2031-04-02",
              description: "Booked palace-complex visit covering the grounds.",
              sourceFilename: "booking.pdf",
              startTime: "09:30",
              title: "River Palace",
            }),
            confirmation: "PALACE123",
            _resolverCandidateId: "stage-1-item-1",
          },
          {
            ...activity({
              date: "2031-04-02",
              sourceFilename: "itinerary.txt",
              title: "River Palace gardens",
            }),
            _resolverCandidateId: "stage-1-item-2",
          },
          {
            ...activity({
              date: "2031-04-02",
              sourceFilename: "itinerary.txt",
              title: "River Palace gallery",
            }),
            _resolverCandidateId: "stage-1-item-3",
          },
        ],
      }))],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
    };
    const parent = draft.activities.find((item) => item.title === "River Palace");
    const children = draft.activities.filter((item) => item._canonicalParentPieceId);

    assert.equal(parent?._canonicalParentPieceId, undefined);
    assert.equal(parent?.startTime, "09:30");
    assert.equal(parent?.confirmation, "PALACE123");
    assert.deepEqual(
      children.map((item) => item.title),
      ["River Palace gardens", "River Palace gallery"]
    );
  });

  await test("canonical notes create one collection per city across repeated city legs", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "rome-notes",
          emptyStage({
            activities: [
              {
                category: "food_dining",
                city: "Rome",
                description: "Pizza ideas.",
                itemType: "note",
                title: "Rome food ideas",
              },
              {
                category: "shopping_tailor",
                city: "Rome",
                description: "Watch shop note.",
                itemType: "note",
                title: "Rome shopping ideas",
              },
            ],
            places: [
              {
                arriveDate: "2019-01-13",
                city: "Rome",
                leaveDate: "2019-01-14",
              },
              {
                arriveDate: "2019-01-24",
                city: "Rome",
                leaveDate: "2019-01-25",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const notes = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities;

    assert.equal(notes.length, 1);
    assert.equal(notes[0]?.title, "Rome Notes & Tips");
    assert.equal(notes[0]?.date, null);
    assert.match(String(notes[0]?.description), /Pizza ideas/);
    assert.match(String(notes[0]?.description), /Watch shop note/);
  });

  await test("independently named same-city stays do not collapse on generic lodging words", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "parallel-stays",
          emptyStage({
            places: [
              {
                arriveDate: "2031-04-01",
                city: "Paris",
                country: "France",
                leaveDate: "2031-04-05",
              },
            ],
            stays: [
              {
                address: "1 Rue Alpha",
                checkIn: "2031-04-01",
                checkOut: "2031-04-05",
                name: "Hotel Central",
                nights: 4,
              },
              {
                address: "9 Rue Beta",
                checkIn: "2031-04-01",
                checkOut: "2031-04-05",
                name: "Hotel Plaza",
                nights: 4,
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });

    assert.deepEqual(
      (result.draft as { stays: Array<{ name: string }> }).stays.map(
        (stay) => stay.name
      ),
      ["Hotel Central", "Hotel Plaza"]
    );
  });

  await test("generic timed placeholders resolve to one uniquely matching named activity", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "day outline",
          emptyStage({
            activities: [
              activity({
                date: "2031-04-05",
                description: "Lunch at 1 PM.",
                sourceFilename: "outline.txt",
                startTime: "13:00",
                title: "Lunch",
              }),
            ],
          })
        ),
        stage(
          "reservation",
          emptyStage({
            activities: [
              activity({
                date: "2031-04-05",
                description: "Reservation for one.",
                sourceFilename: "reservation.txt",
                startTime: "13:00",
                title: "U Maliru lunch reservation",
              }),
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "April 1-10, 2031" },
    });
    const activities = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities;

    assert.equal(activities.length, 1);
    assert.equal(activities[0]?.title, "U Maliru lunch reservation");
  });

  await test("source hierarchy keeps city-reference venues out of a dated itinerary block", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "vienna hierarchy",
          emptyStage({
            activities: [
              {
                ...activity({
                  date: "2031-04-04",
                  sourceFilename: "vienna.txt",
                  title: "Ferris wheel",
                }),
                evidenceRole: "atomic_candidate",
                sourceHeadingPath: ["Saturday", "Explore Vienna"],
                sourceSectionLabel: "Explore Vienna",
                sourceSectionType: "dated_itinerary",
              },
              {
                ...activity({
                  date: "2031-04-04",
                  sourceFilename: "vienna.txt",
                  title: "Mozarthaus",
                }),
                city: "Vienna",
                evidenceRole: "city_note_candidate",
                sourceHeadingPath: ["Saturday", "Vienna"],
                sourceSectionLabel: "Vienna",
                sourceSectionType: "city_reference",
              },
              {
                ...activity({
                  date: "2031-04-04",
                  sourceFilename: "vienna.txt",
                  title: "Leopold Museum",
                }),
                city: "Vienna",
                evidenceRole: "city_note_candidate",
                sourceHeadingPath: ["Saturday", "Vienna"],
                sourceSectionLabel: "Vienna",
                sourceSectionType: "city_reference",
              },
            ],
            places: [
              {
                arriveDate: "2031-04-03",
                city: "Vienna",
                leaveDate: "2031-04-06",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "April 3-6, 2031" },
    });
    const activities = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities;

    assert.equal(
      activities.filter((item) => item.itemType !== "note").length,
      1
    );
    assert.equal(activities.find((item) => item.itemType === "note")?.title, "Vienna Notes & Tips");
  });

  await test("chunk-local precise time beats a conflicting spine normalization", () => {
    const transport = (departureTime: string) => ({
      arrival: "JFK",
      arrivalTime: "18:45",
      confirmation: "GHFHPG",
      date: "2019-01-25",
      departure: "FCO",
      departureTime,
      description: null,
      number: "DL1043",
      provider: "Delta",
      title: "Flight Rome to JFK",
      type: "flight",
    });
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        {
          label: "trip spine",
          source: "model_spine",
          stage: emptyStage({ transport: [transport("02:45")] }),
        },
        {
          label: "return flight booking",
          source: "model_chunk",
          sourceProvenance: "text_layer",
          stage: emptyStage({ transport: [transport("14:45")] }),
        },
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });

    assert.equal(
      (result.draft as { transport: Array<{ departureTime: string }> })
        .transport[0]?.departureTime,
      "14:45"
    );
  });

  await test("missing named source evidence becomes review-required content", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "missing venue",
          emptyStage({
            missingDetails: [
              {
                answerType: "confirm",
                confidence: "low",
                evidence: "The itinerary lists Hospital in the Rock.",
                guessedValue: null,
                prompt: "Where should Hospital in the Rock appear?",
                reason: "The source lists the venue but its placement is unclear.",
                relatedTitle: "Hospital in the Rock",
                subjectType: "item",
                targetField: "date",
              },
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const recovered = (result.draft as {
      activities: Array<Record<string, unknown>>;
    }).activities.find((item) => item.title === "Hospital in the Rock");

    assert.ok(recovered);
    assert.equal(recovered?._recoveryRequired, true);
  });

  await test("canonical evidence preserves private source text for the public projection", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [
        stage(
          "private access",
          emptyStage({
            activities: [
              activity({
                date: "2031-04-01",
                description: "WiFi password: secretword. Door code: 1234.",
                sourceFilename: "private.txt",
                title: "Arrival note",
              }),
            ],
          })
        ),
      ],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });
    const description = String(
      (result.draft as { activities: Array<{ description: string }> }).activities[0]
        ?.description
    );

    assert.match(description, /secretword|1234/);
  });

  await test("an undated committed activity gets one provisional city date and one date question", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [{
        label: "Rome plans",
        source: "model_chunk",
        sourceText: "Rome\nWe definitely want to visit the Borghese Gallery.",
        stage: emptyStage({
          activities: [{
            category: "art_culture",
            city: "Rome",
            date: null,
            description: "We definitely want to visit this while in Rome.",
            evidenceRole: "atomic_candidate",
            itemType: "activity",
            sourceSectionType: "unknown",
            title: "Borghese Gallery",
          }],
          places: [{
            arriveDate: "2031-04-01",
            city: "Rome",
            leaveDate: "2031-04-05",
          }],
        }),
      }],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };
    const activity = draft.activities.find(
      (item) => item.title === "Borghese Gallery"
    );
    const question = draft.missingDetails.find(
      (item) => item.relatedTitle === "Borghese Gallery"
    );

    assert.equal(activity?.date, "2031-04-02");
    assert.equal(question?.answerType, "date");
    assert.equal(question?.guessedValue, "2031-04-02");
    assert.equal(question?.answerMin, "2031-04-01");
    assert.equal(question?.answerMax, "2031-04-05");
    assert.equal(question?.prompt, "Which day does Borghese Gallery happen?");
  });

  await test("a fixed alternative slot stays one flexible card without a question", () => {
    // 2026-07-17 disjunction rule (approved Central Europe ground truth):
    // an explicit "or" is a committed slot with an unresolved choice — ONE
    // flexible traveler card keeps the alternatives, and no automatic
    // question is generated. The maker can edit the card directly.
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("museum choice", emptyStage({
        activities: [activity({
          date: "2031-04-02",
          description: "Choose one museum for the morning slot.",
          sourceFilename: "itinerary.txt",
          title: "Morning: Museum X or Museum Y",
        })],
      }))],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };
    const slotQuestion = draft.missingDetails.find(
      (item) =>
        item.targetField === "title" &&
        /museum x|museum y/i.test(String(item.prompt ?? ""))
    );

    assert.equal(draft.activities.length, 1);
    assert.match(String(draft.activities[0]?.title), /museum x or museum y/i);
    assert.equal(slotQuestion, undefined);
  });

  await test("a timed generic meal stays visible and asks for only the venue", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("lunch slot", emptyStage({
        activities: [activity({
          date: "2031-04-02",
          sourceFilename: "itinerary.txt",
          startTime: "13:00",
          title: "Lunch",
        })],
      }))],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };

    assert.equal(draft.activities.length, 1);
    assert.equal(draft.missingDetails[0]?.targetField, "locationName");
    assert.equal(
      draft.missingDetails[0]?.prompt,
      "Do you have a specific lunch place for 1:00 PM, or should we keep it nearby?"
    );
  });

  await test("isolated generic meals and ambiguous bare terms stay out of the app with lineage", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("loose notes", emptyStage({
        activities: [
          {
            category: "food_dining",
            city: null,
            date: null,
            description: null,
            evidenceRole: "atomic_candidate",
            itemType: "activity",
            sourceSectionType: "unknown",
            title: "Lunch",
          },
          {
            category: "food_dining",
            city: null,
            date: null,
            description: null,
            evidenceRole: "city_note_candidate",
            itemType: "note",
            sourceSectionType: "unknown",
            title: "Borkonya",
          },
        ],
      }))],
      tripOverview: { dateRange: "April 1-5, 2031" },
    });
    const draft = result.draft as {
      _evidence: { dispositions: Array<Record<string, unknown>> };
      activities: Array<Record<string, unknown>>;
    };

    assert.equal(draft.activities.length, 0);
    assert.equal(draft._evidence.dispositions.length, result.observations.length);
    assert.equal(
      new Set(
        draft._evidence.dispositions.map((item) => item.observationId)
      ).size,
      result.observations.length
    );
    assert.ok(
      draft._evidence.dispositions.some(
        (item) => item.reasonCode === "needs_identity_enrichment"
      )
    );
  });

  await test("explicit cancellations and replacements become concise Calls", () => {
    const cancelled = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("cancellation", emptyStage({
        activities: [
          activity({
            date: "2031-04-02",
            description: "This museum booking was cancelled.",
            sourceFilename: "update.txt",
            title: "Museum booking",
          }),
          activity({
            date: "2031-04-02",
            description: "Walk through the old town.",
            sourceFilename: "itinerary.txt",
            title: "Old Town walk",
          }),
        ],
      }))],
      tripOverview: { dateRange: "April 1-5, 2031" },
    }).draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };
    assert.deepEqual(
      cancelled.activities.map((item) => item.title),
      ["Old Town walk"]
    );
    assert.equal(cancelled.missingDetails.length, 1);
    assert.equal(cancelled.missingDetails[0]?._canonicalReviewDisposition, "call");
    assert.match(String(cancelled.missingDetails[0]?.prompt), /left out Museum booking/i);

    const updated = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("replacement", emptyStage({
        activities: [activity({
          date: "2031-04-02",
          description: "Updated time: the museum now starts at 3 PM.",
          sourceFilename: "update.txt",
          startTime: "15:00",
          title: "Museum booking",
        })],
      }))],
      tripOverview: { dateRange: "April 1-5, 2031" },
    }).draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };
    assert.equal(updated.activities.length, 1);
    assert.equal(updated.missingDetails.length, 1);
    assert.match(String(updated.missingDetails[0]?.prompt), /updated source details/i);
  });

  await test("model inventions without source support are suppressed; codes are verified", () => {
    // Defect docket 2026-07-17: a record whose distinctive title words appear
    // nowhere in its producing chunk's source text is a model invention and
    // never becomes a card ("Prague Walking Tour" dated into the Rome leg).
    // Confirmation codes must appear verbatim in source text or are scrubbed.
    const sourceText = [
      "Thursday, January 24th Fly back to Rome",
      "Watches in Rome. Via della Fontanella Borghese 33.",
      "Tour Rome in afternoon/evening (or work)",
      "Wizz Air Flight W6 2339 Confirmation RDGHMT",
    ].join("\n");
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [{
        label: "rome-day-chunk",
        source: "model_chunk",
        sourceFilename: "rome-day.txt",
        sourceText,
        stage: emptyStage({
          activities: [
            activity({
              date: "2019-01-24",
              sourceFilename: "rome-day.txt",
              title: "Watches in Rome errand",
            }),
            // Invention: nothing about Prague in this chunk's text.
            activity({
              date: "2019-01-24",
              sourceFilename: "rome-day.txt",
              title: "Prague Walking Tour",
            }),
          ],
          transport: [{
            arrival: "Rome FCO",
            confirmation: "FAKECODE99",
            date: "2019-01-24",
            departure: "Budapest",
            departureTime: "12:20",
            provider: "Wizz Air",
            sourceFilename: "rome-day.txt",
            title: "Flight Budapest to Rome",
            type: "flight",
          }],
        }),
      }],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      transport: Array<Record<string, unknown>>;
    };

    assert.equal(
      draft.activities.some((item) => /watches/i.test(String(item.title))),
      true,
      "supported activity survives"
    );
    assert.equal(
      draft.activities.some((item) => /prague/i.test(String(item.title))),
      false,
      "unsupported invention is suppressed to lineage"
    );
    const flight = draft.transport.find((item) =>
      /budapest/i.test(String(item.title ?? item.routeLabel ?? ""))
    );
    assert.ok(flight, "flight survives");
    assert.equal(
      flight.confirmation ?? null,
      null,
      "confirmation code absent from source text is scrubbed"
    );
  });

  await test("slot collisions collapse alias-titled duplicates into one booked card", () => {
    // Defect docket 2026-07-17 (triple lunch, live run 7.17.1): three cards
    // with zero shared title tokens all claim the same 13:00 food slot.
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("prague-day-5", emptyStage({
        activities: [
          activity({
            category: "food_dining",
            date: "2019-01-16",
            sourceFilename: "plan.pdf",
            startTime: "13:00",
            title: "U Maliru",
          }),
          {
            ...activity({
              category: "food_dining",
              date: "2019-01-16",
              sourceFilename: "plan.pdf",
              startTime: "13:00",
              title: "Restaurant Festival reservation",
            }),
            confirmation: "R8167918050",
            description: "Restaurant Festival reservation at U Maliru 1543 for 1 person.",
          },
          activity({
            category: "food_dining",
            date: "2019-01-16",
            sourceFilename: "plan.pdf",
            startTime: "13:00",
            title: "Lunch",
          }),
        ],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
    };
    const lunchCards = draft.activities.filter(
      (item) =>
        item.itemType !== "note" &&
        String(item.date) === "2019-01-16" &&
        /u maliru|restaurant festival|^lunch$/i.test(String(item.title))
    );

    assert.equal(lunchCards.length, 1, "one card survives the 13:00 slot");
    assert.match(
      String(lunchCards[0].title),
      /u maliru/i,
      "venue-name title wins the label"
    );
  });

  await test("two different booking codes in one slot stay separate", () => {
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("double-booked", emptyStage({
        activities: [
          {
            ...activity({
              category: "food_dining",
              date: "2019-01-16",
              sourceFilename: "plan.pdf",
              startTime: "19:00",
              title: "Dinner at Alpha",
            }),
            confirmation: "AAAA1111",
          },
          {
            ...activity({
              category: "food_dining",
              date: "2019-01-16",
              sourceFilename: "plan.pdf",
              startTime: "19:00",
              title: "Dinner at Beta",
            }),
            confirmation: "BBBB2222",
          },
        ],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
    };
    const dinners = draft.activities.filter((item) =>
      /dinner at/i.test(String(item.title))
    );

    assert.equal(dinners.length, 2, "distinct bookings are affirmative evidence");
  });

  await test("transport and stay shadow activities are suppressed on multi-segment days", () => {
    // Defect docket 2026-07-17: four flight-shadow activities survived on
    // two-segment days (old `matches === 1` guard), including a Delta 1043
    // twin whose corrupted AM time blocked reconciliation; plus one bare
    // "AirBNB" activity duplicating the stay record.
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("shadow-day", emptyStage({
        activities: [
          activity({
            category: "arrival_departure",
            date: "2019-01-25",
            sourceFilename: "plan.pdf",
            title: "Flight FCO to JFK",
          }),
          {
            ...activity({
              category: "arrival_departure",
              date: "2019-01-25",
              sourceFilename: "plan.pdf",
              title: "Fly home",
            }),
            description: "Delta 1043 FCO -> JFK 2:45 -> 6:45 AM.",
          },
          activity({
            category: "accommodation",
            date: "2019-01-15",
            sourceFilename: "plan.pdf",
            title: "AirBNB",
          }),
        ],
        places: [
          { arriveDate: "2019-01-14", city: "Prague", country: "Czechia", leaveDate: "2019-01-18" },
          { arriveDate: "2019-01-24", city: "Rome", country: "Italy", leaveDate: "2019-01-25" },
        ],
        stays: [{
          address: "Michalska 431/5, Prague",
          checkIn: "2019-01-14",
          checkOut: "2019-01-18",
          name: "Prague Airbnb",
          sourceFilename: "plan.pdf",
        }],
        transport: [
          {
            arrival: "JFK",
            arrivalTime: "18:45",
            confirmation: null,
            date: "2019-01-25",
            departure: "FCO",
            departureTime: "14:45",
            provider: "Delta 1043",
            sourceFilename: "plan.pdf",
            title: "Flight FCO to JFK",
            type: "flight",
          },
          {
            arrival: "DCA",
            arrivalTime: "21:50",
            confirmation: null,
            date: "2019-01-25",
            departure: "JFK",
            departureTime: "20:30",
            provider: "Delta 2934",
            sourceFilename: "plan.pdf",
            title: "Flight JFK to DCA",
            type: "flight",
          },
        ],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      transport: Array<Record<string, unknown>>;
    };
    const flightShadows = draft.activities.filter(
      (item) =>
        item.itemType !== "note" && /flight|fly/i.test(String(item.title))
    );
    const stayShadows = draft.activities.filter(
      (item) => item.itemType !== "note" && /airbnb/i.test(String(item.title))
    );

    assert.equal(draft.transport.length, 2, "both segments survive as transport");
    assert.equal(flightShadows.length, 0, "flight shadow activities suppressed");
    assert.equal(stayShadows.length, 0, "bare stay-name activity suppressed");
  });

  await test("same-site stops group under the site container; spread day-trip sights never group", () => {
    // Grouping doctrine v3 (2026-07-17): Prague Castle owns the stops inside
    // its grounds (~300 m), keeping its own source title, timed child allowed.
    // Kutná Hora's sights are kilometres apart on a 4-card day: 3 discrete
    // activities, no group (density gate + geo verification).
    const locatedActivity = (
      title: string,
      date: string,
      lat: number,
      lng: number,
      extra: Record<string, unknown> = {}
    ) => ({
      ...activity({ category: "art_culture", city: null as unknown as string, date, sourceFilename: "plan.pdf", title }),
      approxLatitude: lat,
      approxLongitude: lng,
      city: null,
      ...extra,
    });
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("castle-and-daytrip", emptyStage({
        activities: [
          // Prague Castle complex, all within ~250 m.
          locatedActivity("Prague Castle complex", "2019-01-16", 50.0900, 14.4000),
          locatedActivity("Changing of the Guard", "2019-01-16", 50.0902, 14.4008, { startTime: "12:00" }),
          locatedActivity("St. Vitus Cathedral", "2019-01-16", 50.0906, 14.4006),
          // Kutná Hora day trip: spread far apart, small day.
          locatedActivity("Sedlec Ossuary", "2019-01-17", 49.9622, 15.2884),
          locatedActivity("Church of St Barbara", "2019-01-17", 49.9446, 15.2632),
          locatedActivity("Silver mines", "2019-01-17", 49.9481, 15.2662),
        ],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
      missingDetails: Array<Record<string, unknown>>;
    };
    const castleParent = draft.activities.find(
      (item) => String(item.title) === "Prague Castle complex"
    );
    const guard = draft.activities.find((item) =>
      /changing of the guard/i.test(String(item.title))
    );
    const vitus = draft.activities.find((item) =>
      /st\. vitus/i.test(String(item.title))
    );
    const kutnaHora = draft.activities.filter((item) =>
      /sedlec|barbara|silver/i.test(String(item.title))
    );

    assert.ok(castleParent, "castle container survives with its source title");
    assert.ok(guard && vitus, "castle stops survive as children");
    assert.equal(guard._canonicalParentPieceId, castleParent._canonicalPieceId);
    assert.equal(vitus._canonicalParentPieceId, castleParent._canonicalPieceId);
    assert.equal(
      kutnaHora.filter((item) => item._canonicalParentPieceId).length,
      0,
      "Kutná Hora sights stay 3 discrete ungrouped activities"
    );
    const groupingCall = draft.missingDetails.find(
      (item) => item._canonicalReviewDisposition === "call" &&
        /included stop/i.test(String(item.prompt ?? ""))
    );
    assert.ok(groupingCall, "grouping produces one statement-style call");
    assert.match(
      String(groupingCall.reason ?? ""),
      /same-site visit/i,
      "the call states the actual rule that fired"
    );
  });

  await test("cross-city note content routes to its owning entity and codes never reach note prose", () => {
    // Defect docket 2026-07-17: a Colosseum ticket (plus booking barcode)
    // OCR'd from the appendix pages inherited Prague from its surroundings
    // and landed inside Prague Notes & Tips.
    const result = clusterExtractedEvidence({
      sourceTransportAnchors: [],
      stages: [stage("appendix-pages", emptyStage({
        activities: [
          {
            ...activity({
              city: "Rome",
              date: "2019-01-13",
              sourceFilename: "plan.pdf",
              startTime: "14:00",
              title: "Colosseum",
            }),
          },
          {
            category: "art_culture",
            city: "Prague",
            date: null,
            description:
              "Colosseum entry ticket. Booking reference QX7YT99A. 4321098765432109. Admit one adult.",
            evidenceRole: "city_note_candidate",
            itemType: "note",
            sourceFilename: "plan.pdf",
            sourceSectionType: "city_reference",
            title: "Ticket screenshot",
          },
          {
            category: "food_dining",
            city: "Prague",
            date: null,
            description: "Try the garlic soup cesnecka at Cafe Louvre.",
            evidenceRole: "city_note_candidate",
            itemType: "note",
            sourceFilename: "plan.pdf",
            sourceSectionType: "city_reference",
            title: "Prague food ideas",
          },
        ],
        places: [
          { arriveDate: "2019-01-13", city: "Rome", country: "Italy", leaveDate: "2019-01-14" },
          { arriveDate: "2019-01-14", city: "Prague", country: "Czechia", leaveDate: "2019-01-18" },
        ],
      }))],
      tripOverview: { dateRange: "January 12-25, 2019" },
    });
    const draft = result.draft as {
      activities: Array<Record<string, unknown>>;
    };
    const pragueNote = draft.activities.find(
      (item) =>
        item.itemType === "note" && /prague/i.test(String(item.title ?? ""))
    );

    assert.ok(pragueNote, "Prague note collection exists");
    const noteText = `${pragueNote.title} ${pragueNote.description ?? ""}`;
    assert.doesNotMatch(noteText, /colosseum/i, "Rome content never enters Prague notes");
    assert.doesNotMatch(noteText, /QX7YT99A|4321098765/i, "booking identifiers never reach note prose");
    assert.match(noteText, /cesnecka/i, "genuine Prague tips survive");
  });
}
